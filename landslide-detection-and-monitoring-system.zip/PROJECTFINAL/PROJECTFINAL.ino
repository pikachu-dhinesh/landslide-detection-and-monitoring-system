#define BLYNK_TEMPLATE_ID "TMPLxxxxxxx"
#define BLYNK_TEMPLATE_NAME "Landslide Monitoring"
#define BLYNK_AUTH_TOKEN "0SEx2ahVXetmT29gqdIqQgMVNn4SDEQd"

#define BLYNK_PRINT Serial

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>

// WIFI
char ssid[] = "geeks";
char pass[] = "1234567890";

// TELEGRAM
String botToken = "8733359977:AAGlXkZ4xSXib6ww8nMUoIIDtyKUlT9_RrE";
String chatID = "1273458005";

// PINS
#define SOIL_PIN 34
#define VIBRATION_PIN 27
#define BUZZER_PIN 26

#define GREEN_LED 14
#define YELLOW_LED 25
#define RED_LED 13

Adafruit_SH1106G display(128, 64, &Wire, -1);
BlynkTimer timer;

// CALIBRATION
int dryValue = 3800;
int wetValue = 1800;

// ALERT CONTROL
String lastStatus = "";
unsigned long lastAlertTime = 0;
const unsigned long alertDelay = 15000;

// ---------------- TELEGRAM ----------------
void sendTelegram(String msg) {
  if (WiFi.status() != WL_CONNECTED) return;

  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;

  msg.replace(" ", "%20");

  String url = "https://api.telegram.org/bot" + botToken +
               "/sendMessage?chat_id=" + chatID +
               "&text=" + msg;

  http.begin(client, url);
  http.GET();
  http.end();
}

// ---------------- MOISTURE ----------------
int readMoisture() {

  int sum = 0;
  for (int i = 0; i < 10; i++) {
    sum += analogRead(SOIL_PIN);
    delay(5);
  }

  int raw = sum / 10;

  int moisture = map(raw, dryValue, wetValue, 0, 100);
  moisture = constrain(moisture, 0, 100);

  Serial.print("RAW: ");
  Serial.print(raw);
  Serial.print(" | Moisture: ");
  Serial.println(moisture);

  return moisture;
}

// ---------------- VIBRATION ----------------
bool detectVibration() {

  int count = 0;
  for (int i = 0; i < 10; i++) {
    if (digitalRead(VIBRATION_PIN) == HIGH) count++;
    delay(3);
  }

  return (count >= 5);
}

// ---------------- BUZZER ----------------
void buzzerControl(String status) {

  static unsigned long lastToggle = 0;
  static bool state = false;
  unsigned long now = millis();

  if (status == "SAFE") {
    digitalWrite(BUZZER_PIN, LOW);
  }
  else if (status == "VIBRATION") {
    if (now - lastToggle > 800) {
      state = !state;
      digitalWrite(BUZZER_PIN, state);
      lastToggle = now;
    }
  }
  else if (status == "DANGER") {
    if (now - lastToggle > 250) {
      state = !state;
      digitalWrite(BUZZER_PIN, state);
      lastToggle = now;
    }
  }
}

// ---------------- OLED ----------------
void showLCD(String status, int moisture) {

  display.clearDisplay();
  display.setTextSize(2);
  display.setCursor(0, 10);
  display.println(status);

  display.setCursor(0, 35);
  display.print(moisture);
  display.println("%");

  display.display();
}

// ---------------- MAIN LOGIC ----------------
void loopTask() {

  int moisture = readMoisture();
  bool vibration = detectVibration();

  Serial.print("Vibration: ");
  Serial.println(vibration);

  String status;

  // -------- NEW LOGIC --------
  if (moisture < 20 && !vibration) {
    status = "SAFE";
  }
  else if (vibration && moisture < 30) {
    status = "VIBRATION";   // only movement
  }
  else if (moisture >= 70 && vibration) {
    status = "DANGER";      // both sensors
  }
  else {
    status = "WARN";        // only moisture
  }

  // -------- LED CONTROL --------
  static unsigned long blinkTimer = 0;
  static bool blinkState = false;

  if (status == "SAFE") {
    digitalWrite(GREEN_LED, HIGH);
    digitalWrite(YELLOW_LED, LOW);
    digitalWrite(RED_LED, LOW);
  }

  else if (status == "VIBRATION") {
    if (millis() - blinkTimer > 500) {
      blinkState = !blinkState;
      digitalWrite(GREEN_LED, blinkState);
      blinkTimer = millis();
    }
    digitalWrite(YELLOW_LED, LOW);
    digitalWrite(RED_LED, LOW);
  }

  else if (status == "WARN") {
    digitalWrite(GREEN_LED, LOW);
    digitalWrite(YELLOW_LED, HIGH);
    digitalWrite(RED_LED, LOW);
  }

  else if (status == "DANGER") {
    digitalWrite(GREEN_LED, LOW);
    digitalWrite(YELLOW_LED, LOW);
    digitalWrite(RED_LED, HIGH);
  }

  Serial.print("Status: ");
  Serial.println(status);

  // BLYNK
  if (Blynk.connected()) {
    Blynk.virtualWrite(V0, moisture);
    Blynk.virtualWrite(V1, status);
    Blynk.virtualWrite(V2, vibration);
  }

  showLCD(status, moisture);
  buzzerControl(status);

  // ALERT
  if (status == "DANGER" && lastStatus != "DANGER" &&
      millis() - lastAlertTime > alertDelay) {

    sendTelegram("⚠ LANDSLIDE ALERT!");
    lastAlertTime = millis();
  }

  lastStatus = status;
}

// ---------------- SETUP ----------------
void setup() {

  Serial.begin(115200);

  pinMode(SOIL_PIN, INPUT);
  pinMode(VIBRATION_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  pinMode(GREEN_LED, OUTPUT);
  pinMode(YELLOW_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);

  display.begin(0x3C, true);

  WiFi.begin(ssid, pass);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);

  timer.setInterval(1000L, loopTask);
}

// ---------------- LOOP ----------------
void loop() {
  Blynk.run();
  timer.run();
}